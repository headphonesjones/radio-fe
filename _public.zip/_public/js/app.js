'use strict';
var App;

App = angular.module('app', ['ngCookies', 'ngResource', 'app.controllers', 'app.directives', 'app.filters', 'app.services']);

App.config([
  '$routeProvider', '$locationProvider', function($routeProvider, $locationProvider, config) {
    $routeProvider.when('/todo', {
      templateUrl: '/partials/todo.html',
      controller: 'TodoCtrl'
    }).when('/view1', {
      templateUrl: '/partials/partial1.html',
      controller: 'AppCtrl'
    }).when('/view2', {
      templateUrl: '/partials/partial2.html',
      controller: 'AppCtrl'
    }).otherwise({
      redirectTo: '/todo'
    });
    return $locationProvider.html5Mode(true);
  }
]);
;'use strict';


// Declare app level module which depends on filters, and services
var myApp = angular.module('radio', ['ngRoute', 'ngSanitize', 'radio.filters', 'radio.services', 'radio.directives', 'radio.controllers', 'ngAnimate', 'ajoslin.promise-tracker', 'ngDisqus']).
  config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/', {templateUrl: 'partials/home.html', controller: 'HomeController'});
    $routeProvider.when('/about', {templateUrl: 'partials/about.html', controller: 'AboutController'});
    $routeProvider.when('/about/:tab', {templateUrl: 'partials/about.html', controller: 'AboutController'}); 
    $routeProvider.when('/media', {templateUrl: 'partials/media.html', controller: 'MediaController'});
    $routeProvider.when('/people', {templateUrl: 'partials/staff.html', controller: 'StaffListController'});
    $routeProvider.when('/people/:id', {templateUrl: 'partials/person.html', controller: 'StaffController'});
    $routeProvider.when('/shows', {templateUrl: 'partials/shows.html', controller: 'ShowListController'});
    $routeProvider.when('/shows/:id', {templateUrl: 'partials/show.html', controller: 'ShowController'});
    $routeProvider.when('/station_news', {templateUrl: 'partials/news_list.html', controller: 'NewsListController'});
    $routeProvider.when('/station_news/:id', {templateUrl: 'partials/news_story.html', controller: 'NewsStoryController'});
    $routeProvider.when('/schedule', {templateUrl: 'partials/schedule.html', controller: 'ScheduleController'});
    $routeProvider.when('/webcam', {templateUrl: 'partials/webcam.html', controller: 'WebcamController'});
    $routeProvider.otherwise({redirectTo: '/'});
  }]);


myApp.config(['$httpProvider', function($httpProvider) {
  $httpProvider.defaults.useXDomain = true;
  $httpProvider.defaults.cache = true;
  delete $httpProvider.defaults.headers.common['X-Requested-With'];
   }
]);

window.disqus_shortname = "radiodepaul";

function loadJS(src, callback) {
    var s = document.createElement('script');
    s.src = src;
    s.async = true;
    s.onreadystatechange = s.onload = function() {
        var state = s.readyState;
        if (!callback.done && (!state || /loaded|complete/.test(state))) {
            callback.done = true;
            callback();
        }
    };
    document.getElementsByTagName('head')[0].appendChild(s);
}

;'use strict';

/* Controllers */
var controllers = angular.module('radio.controllers', []);

controllers.controller('navCtrl', ['$scope', '$location', '$rootScope',function ($scope, $location, $rootScope) {

    $scope.navClass = function (page) {
        var currentRoute = $location.path().substring(1) || 'home';
        return page === currentRoute ? 'active' : '';
	};
    $scope.isHome = function () {
    	var currentRoute = $location.path().substring(1) || 'home';
    	return 'home' === currentRoute;
    	
    };

    $scope.playMusic = function (){
        $rootScope.$broadcast('player', 'play');
    };

    $scope.$on('player', function(event, args) {
			if (args == 'playing') {
				$scope.playing = true;
            }
		    if (args == 'paused') {
		    	$scope.playing = false;

		    }	
	});

}]);
controllers.controller('sidebarController', ['$scope', function ($scope) {
	$scope.twitter = "radiodepauldjs";
}]);
controllers.controller('HomeController', ['$scope', 'News', 'Events', 'Page', function($scope, News, Events, Page){
    Page.setTitle('Home');
    $scope.page = "Radio DePaul"
	News.query(function(data){$scope.news = data;});
	Events.query(function(data){$scope.events = data;});
}]);

controllers.controller('NewsListController', ['$scope', 'News', 'Page', function($scope, News, Page){
    Page.setTitle('News');
	News.query(function(data){$scope.news = data;});
}]);

controllers.controller('NewsStoryController', ['$scope', 'News', 'Page', function($scope, News, Page){
	News.get(function(data){$scope.news = data;Page.setTitle($scope.news.headline)});
}]);

controllers.controller('ScheduleController', ['$scope', 'Schedule', 'Page', function($scope, Schedule, Page){
	Page.setTitle('Schedule');
	Schedule.query(function(data){$scope.schedule = data;});
	$scope.days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
	$scope.selected = $scope.days[new Date().getDay()];
}]);

controllers.controller('OnAirController', ['$scope', '$rootScope', 'Shows', function($scope, $rootScope, Shows){
	$scope.playing = false;

	Shows.onair(function(data){$scope.show = data;});

	$scope.$on('player', function(event, args) {
		if (args == 'play') {
			if ($scope.playing == false) {
				$scope.playMusic();
			}
		}
	});

	$scope.playMusic = function() {
		if ($scope.soundObject) {
			$scope.soundObject.play();
		} else {
			$scope.loadSM2();
		}
		$scope.playing = true;
	 	$rootScope.$broadcast('player', 'playing');
	}

	$scope.pauseMusic = function() {
		$scope.soundObject.pause();
		$scope.playing = false;
     	$rootScope.$broadcast('player', 'paused');
	}
	$scope.loadSM2 = function() {
		//move load code here

		soundManager.setup({
			url: '/js/swf/', 
			flashVersion: 9, 
			onready: function() { 
				$scope.soundObject = soundManager.createSound({
				  id: 'mySound',
				  url: 'http://rock.radio.depaul.edu:8000/stream.mp3&137714603810',
				  autoLoad: true,
				  autoPlay: true,
				  volume: 75,
				  useHTML5Audio: true,
				});
			}
		});

	}
   	
}]);

controllers.controller('AboutController', ['$scope', 'Managers', 'Awards', '$routeParams', 'Page', function($scope, Managers, Awards, $routeParams, Page){
	Page.setTitle('About');
	var startTab = $routeParams.tab || "managers"
	$scope.tabs = ['Managers', 'Contact', 'Mission Statement', 'Join Radio DePaul', 'Sponsor Radio DePaul', 'Awards and Recognition'];

	//Set tab to routeParams tab
	for(var i = 0; i < $scope.tabs.length; i++) {
		if($scope.tabs[i].toLowerCase().replace(/ /g,"_") == startTab) {
			$scope.tabs.active = ($scope.tabs[i]);
		}
	}
	Managers.query(function(data){$scope.managers = data;});
	Awards.query(function(data){$scope.awards = data;}); //401 error from the server
}]);

controllers.controller('MediaController', ['$scope', 'Flickr', '$http', 'Page', function($scope, Flickr, $http, Page){
    Page.setTitle('Media');
	$scope.photosets = ['72157627431049317', '72157627556017792', '72157627638190531', '72157627555308552', '72157627431314949', '72157627431238035'];

}]);

controllers.controller('ShowListController', ['$scope', 'Shows', 'Page', function($scope, Shows, Page){
    Page.setTitle('Shows');
	Shows.query(function(data){
		$scope.shows = data;
	});

	$scope.showSearchFilter = function (obj) {
	    var re = new RegExp($scope.showSearchText, 'i');
    	return !$scope.showSearchText || re.test(obj.title);
	};
}]);

controllers.controller('ShowController', ['$scope', 'Shows', 'Page', function($scope, Shows, Page){
	Shows.get(function(data){$scope.show = data;Page.setTitle($scope.show.title)});
}]);

controllers.controller('StaffListController', ['$scope', 'Staff', 'Page', function($scope, Staff, Page){
    Page.setTitle('Staff');
	$scope.currentPage = 0;
    $scope.pageSize = 10;

    $scope.filter = function() {
 		$scope.currentPage = 0;
    };
	Staff.query(function(data){
		$scope.staff = data;
		$scope.numberOfPages=function(){
        	return Math.ceil($scope.staff.length/$scope.pageSize);                
    	}
	});

	$scope.staffSearchFilter = function (obj) {
	    var re = new RegExp($scope.staffSearchText, 'i');
	    $scope.numberOfPages =function(){return Math.ceil($scope.filteredItems.length/$scope.pageSize)}; 
    	return !$scope.staffSearchText || re.test(obj.name);
	};
}]);

controllers.controller('StaffController', ['$scope', 'Staff', 'Page', function($scope, Staff, Page){
	Staff.get(function(data){$scope.person = data;Page.setTitle($scope.person.name)});
}]);

controllers.controller('ChatController', ['$scope', '$sce', function($scope, $sce){
	$scope.trustSrc = function(src) {
    return $sce.trustAsResourceUrl(src);
    }
	$scope.chatURL = null;
	$scope.showChat = false;
 
	$scope.toggleChat = function () {
       	$scope.showChat = !$scope.showChat;
       	if (!$scope.chatURL) {
       		$scope.chatURL = "http://cdn.livestream.com/embed/radiodepaulchannel?layout=6&amp;height=300&amp;width=250&amp;showTimestamp=true";
       	}
    };

}]);

controllers.controller('PopUpPlayerController', ['$scope', 'PopupPlayer', function($scope, PopupPlayer){
	PopupPlayer.get(function(data){$scope.show = data;});
	$scope.popuplayer = data;

}]);

controllers.controller('HeadController', ['$scope', 'Page', function($scope, Page) {
	$scope.Page = Page;
}]);

controllers.controller('WebcamController', ['$scope', function($scope){
    
	loadJS('http://jwpsrv.com/library/GgcroA5wEeOwaBIxOUCPzg.js', function() { 
		jwplayer('webcam-player').setup({
	        file: 'rtmp://ec2-67-202-3-106.compute-1.amazonaws.com/rtplive/mp4:camera.stream',
	        //image: 'Enter a JPG or PNG preview image URL',
	        title: 'Radio DePaul Webcam',
	        width: '100%',
	        aspectratio: '16:9',
	        fallback: 'false',
	        primary: 'flash'
	    });
    });
}]);
;'use strict';

/* Directives */

var directives = angular.module('radio.directives', []);

directives.directive('pagination', function() {
	return {
		template: '<div id="pagination-container">' +
		          '<ul class="pagination" ng-hide="numPages() < 2">' + 
		          '<li ng-class="{disabled: currentPage == 0}" ng-click="gotoPage(1)">«</li>' +
		          '<li ng-class="{disabled: currentPage == 0}" ng-click="prevPage()"><</li>' +
    			  '<li ng-repeat="page in pages" ng-class="{active: currentPage+1 == page}"" ng-click="gotoPage(page)">{{page}}</li>' +
                  '<li ng-class="{disabled: currentPage>= numPages() - 1}" ng-click="nextPage()">></li>' +
                  '<li ng-class="{disabled: currentPage>= numPages() - 1}" ng-click="gotoPage(numPages())">»</li></ul>' +
                  '</div>',
		replace: 'true',
		restrict: 'EA',
		scope: {
			pageSize: '=',
			count: '=',
		},
    	link: function($scope, element, attrs) {
			$scope.$parent.currentPage = $scope.currentPage = 0;
			$scope.$parent.pageSize = $scope.pageSize;
			$scope.$watch('count', function() {
				$scope.$parent.currentPage = $scope.currentPage = 0;
	    		var range = [];
				for(var i=0;i<$scope.numPages();i++) {
				  range.push(i+1);
				}
				$scope.pages = range;
			});

			$scope.numPages = function () {
				return Math.ceil($scope.count / $scope.pageSize); 
			}
			$scope.nextPage = function () {
				if ($scope.numPages() > $scope.currentPage + 1) {
					$scope.$parent.currentPage = $scope.currentPage = $scope.currentPage + 1;
				}
			}
			$scope.prevPage = function () {
				if ($scope.currentPage - 1 > 0) {
					$scope.$parent.currentPage = $scope.currentPage = $scope.currentPage - 1;				
				}
			}
			$scope.gotoPage = function (page) {
				$scope.$parent.currentPage = $scope.currentPage = page - 1;				
			}


		}		
	}
});


directives.directive('twitter', function() {
  return {
	replace: false,
  	restrict: 'EA',
	scope: {
		twitter: '=',
	},
    link: function($scope, element, attrs) {
    	element.addClass('ng-hide');
	    $scope.$watch('twitter', function () {
	    	if ($scope.twitter) {
		      twttr.ready(function(twttr) {
		        twttr.widgets.createTimeline(
		          '363308094438133760',
		          angular.element(element)[0],
		          false,
		          {
		        	width: attrs.width || "700",
		        	height: attrs.height || "250",
		        	screenName: $scope.twitter,
		          }
		        );
		        element.removeClass('ng-hide');
		      }); 
	    	}
	    }, true);
    }
  };
});

directives.directive('flickr', function() {
	return {
		restrict: 'E',
	  	controller: function ($scope) {
	  		this.setPhotos = function(photos) {
	  			$scope.photos = photos;
	  		}
	  	}
	}
});

directives.directive('lightbox', function() {
  return {
    require: "^flickr",
  	replace: true,
  	restrict: 'E',
  	//template: '<div class="lightbox">{{photos}}</div>',
  	templateUrl: 'partials/lightbox.html',
  	link: function(scope, element, attrs, flickrCtrl) {

  		//scope.currentPhoto = scope.photos[0];
  		scope.setCurrentPhoto = function(photo) {
  			scope.currentPhoto = photo;
  		}
  	}

  }
});

directives.directive('photoset', function($http) {
  return {
    require: "^flickr",
  	replace: true,
  	restrict: 'E',
  	template: '<div class="thumbnail">' +
  	            '<h3>{{photoset.title._content}}</h3>' +
  	               '<div class="thumbnail-image" ng-click="showPhotoset(photoset);">' +
  	                 '<img ng-src="http://farm{{photoset.farm}}.static.flickr.com/{{photoset.server}}/{{photoset.primary}}_{{photoset.secret}}_m.jpg" width="215" />' +
  	               '</div>' +
  	           '</div>',
  	scope: {
  	    id: '@'
  	},
  	link: function(scope, element, attrs, flickrCtrl) {
  		$http.jsonp('http://api.flickr.com/services/rest/?format=json&method=flickr.photosets.getInfo&photoset_id=' + scope.id + '&api_key=8ba7f50062d534406009b45aeb73eb90&jsoncallback=JSON_CALLBACK').
		   success(function(data, status, headers, config) {
			scope.photoset = data.photoset;
		   });
		scope.showPhotoset = function (photoset) {
			$http.jsonp('http://api.flickr.com/services/rest/?format=json&method=flickr.photosets.getPhotos&photoset_id=' + photoset.id + '&api_key=8ba7f50062d534406009b45aeb73eb90&jsoncallback=JSON_CALLBACK').
		       success(function(data, status, headers, config) {
			    console.log(data);
			    scope.photos = data.photoset.photo;
			    flickrCtrl.setPhotos(data.photoset.photo);
		   }); 
		}
    }
  }

});

;'use strict';

var filters = angular.module('radio.filters', []);

filters.filter('truncate', function () {
    return function (text, length, end) {
        if (isNaN(length))
            length = 10;

        if (end === undefined)
            end = "...";

        if (text.length <= length || text.length - end.length <= length) {
            return text;
        }
        else {
            return String(text).substring(0, length-end.length) + end;
        }

    };
});

filters.filter('startFrom', function() {
    return function(input, start) {
        if(input) {
            start = +start; //parse to int
            return input.slice(start);
        }
        return [];
    }
});

filters.filter('newlines', function () {
    return function(text) {
        if(text) {
            return text.replace(/\n/g, '</p><p>');
        }
    }
});  
;'use strict';
/* Services */
var apiUrl = 'http://radiodepaul.herokuapp.com/api/v1/'; 
/* var apiUrl = 'http://localhost:3000/api/v1/';*/

angular.module('radio.services', [])
  .factory('Page', function() {
   var title = 'Radio DePaul';
   return {
     title: function() { return title + " | Radio DePaul"; },
     setTitle: function(newTitle) { title = newTitle }
   };
}).factory('News', ['$http', '$routeParams', function($http, $routeParams){
  return {  
    query: function(callback) {
    $http.jsonp(apiUrl + 'news_posts.js?callback=JSON_CALLBACK').
    success(function(data, status, headers, config) {
         callback(data);
        });
  },
    get: function(callback) {
      $http.jsonp(apiUrl + 'news_posts/'+$routeParams['id']+'.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
          callback(data);
    });
  }
}
}]).factory('Events', ['$http', function($http){
  return {
    query: function(callback) {
      $http.jsonp(apiUrl + 'events.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    } 
  }
}]).factory('Schedule', ['$http', function($http){
  return {
    query: function(callback) {
      $http.jsonp(apiUrl + 'slots.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    } 
  }}]).factory('Managers', ['$http', function($http){
  return {
    query: function(callback) {
      $http.jsonp(apiUrl + 'managers.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    } 
  }}]).factory('Awards', ['$http', function($http){
  return {
    query: function(callback) {
      $http.jsonp(apiUrl + 'awards.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    } 
  }}]).factory('Flickr', ['$http', function($http){
  return {
    getList: function(callback) {
      $http.jsonp('http://api.flickr.com/services/rest/?method=flickr.photosets.getList&api_key=8ba7f50062d534406009b45aeb73eb90&user_id=66957222%40N07&format=json&jsoncallback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    },
    getPhotos: function(callback) {
      $http.jsonp('http://api.flickr.com/services/rest/?format=json&method=flickr.photosets.getPhotos&photoset_id=' + photoset_id + '&api_key=8ba7f50062d534406009b45aeb73eb90').
      success(function(data, status, headers, config) {
            callback(data);
      });
    },
    getInfo: function(callback) {
      
    }
  }}]).factory('Shows', ['$http', '$routeParams', function($http, $routeParams){
  return {
    get: function(callback) {
      $http.jsonp(apiUrl + 'shows/' + $routeParams['id'] +'.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    },
    onair: function(callback) {
      $http.jsonp(apiUrl + 'shows/onair.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    },    
    query: function(callback) {
      $http.jsonp(apiUrl + 'shows.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    } 
  }}]).factory('Staff', ['$http', '$routeParams', function($http, $routeParams){
  return {
    get: function(callback) {
    $http.jsonp(apiUrl + 'people/' + $routeParams['id'] +'.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    },     
    query: function(callback) {
      $http.jsonp(apiUrl + 'people.js?callback=JSON_CALLBACK').
      success(function(data, status, headers, config) {
            callback(data);
      });
    }
  }}]);


;
//@ sourceMappingURL=app.js.map