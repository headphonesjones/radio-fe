var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("<!DOCTYPE html>\n<html lang=\"en\" ng-app=\"radio\"></html>\n<!--[if lte IE 7]>\n<script src=\"http://cdnjs.cloudflare.com/ajax/libs/json2/20110223/json2.js\"></script>\n<![endif]-->\n<head>\n  <meta charset=\"utf-8\">\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n  <title ng-bind-template=\"{{title}}\"></title>\n  <meta name=\"description\" content=\"\">\n  <meta name=\"author\" content=\"\">\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n  <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"/favicon.ico\">\n  <link rel=\"stylesheet\" href=\"css/app.css\">\n  <script src=\"js/modernizr.js\"></script>\n  <script>\n    window.brunch = window.brunch || {};\n    window.brunch['auto-reload'] = { enabled: true };\n    \n  </script>\n</head>\n<body>\n  <header><a href=\"/\"><img id=\"logo\" src=\"/img/logo.png\"></a>\n    <nav ng-controller=\"navCtrl\">\n      <div id=\"left-side-nav-holder\">\n        <ul id=\"left-side-nav\">\n          <li><a href=\"/#\" ng-class=\"navClass(&quot;home&quot;)\">Home</a></li>\n          <li><a href=\"/#/schedule/\" ng-class=\"navClass(&quot;schedule&quot;)\">Schedule</a></li>\n          <li><a href=\"/#/shows/\" ng-class=\"navClass(&quot;shows&quot;)\">Shows</a></li>\n          <li><a href=\"/#/people/\" ng-class=\"navClass(&quot;people&quot;)\">Staff</a></li>\n        </ul>\n      </div>\n      <div id=\"right-side-nav-holder\">\n        <ul id=\"right-side-nav\">\n          <li><a href=\"/#/media/\" ng-class=\"navClass(&quot;media&quot;)\">Media</a></li>\n          <li><a href=\"/#/about/\" ng-class=\"navClass(&quot;about&quot;)\">About</a></li>\n          <li><a href=\"http=//radiodepaul.herokuapp.com/application\">Apply</a></li>\n          <li><a id=\"launchPlayer\" href=\"javascript=void(0);\" ng-click=\"playMusic()\" ng-class=\"(active= playing)\">Listen Now</a></li>\n        </ul>\n      </div><a href=\"/sports/\" target=\"_self\"><img id=\"sports-ball\" src=\"/img/ball2.png\"></a>\n    </nav><img id=\"home_image\" ng-controller=\"navCtrl\" ng-src=\"/img/station.jpg\" ng-show=\"isHome()\">\n    <div class=\"container\">\n      <article ng-view></article>\n      <aside id=\"sidebar\" ng-controller=\"sidebarController\">\n        <section twitter=\"twitter\" height=\"300\"></section>\n        <section id=\"fb-likes\">\n          <div id=\"fb-root\">\n            <div ata-href=\"https://www.facebook.com/radiodepaul\" data-width=\"250\" data-show-faces=\"true\" data-header=\"true\" data-stream=\"false\" data-show-border=\"false\" class=\"fb-like-box\"></div>\n          </div>\n        </section>\n      </aside>\n    </div>\n    <footer>\n      <div id=\"footer-links-holder\"><a href=\"http://www.depaul.edu/Pages/copyright.aspx\">© 2001-2013 |</a><a href=\"http://depaul.edu/\">DePaul University |</a><a href=\"http://www.depaul.edu/Pages/disclaimer.aspx\">Disclaimer |</a><a href=\"http://www.depaul.edu/Pages/contact-us.aspx\">Contact DePaul University |</a><a href=\"http://emergencyplan.depaul.edu/Pages/default.aspx\">Emergency Plan |</a><a href=\"http://dab.depaul.edu/\">DePaul Activities Board (DAB) |</a><a href=\"http://www.depauliaonline.com/\">The DePaulia |</a><a href=\"http://communication.depaul.edu/Student Work/Good Day DePaul/\">Good Day DePaul</a></div>\n    </footer>\n    <div id=\"player_fixed\">\n      <div id=\"now_playing_light\">\n        <p>On Air</p>\n      </div>\n      <div id=\"now_playing\" ng-controller=\"OnAirController\">\n        <div id=\"image-title-container\"><img ng-src=\"{{show.photo_thumb}}\" class=\"player-show-image\">\n          <div id=\"on-air-show-text\">\n            <div id=\"showtitle\">\n              <h2><a href=\"/#/shows/{{show.id}}\">{{show.title}}</a></h2>\n              <h3><span id=\"host-text\">Host(s) </span><span id=\"on-air-host-list\" ng-repeat=\"host in show.hosts\"><a id=\"playing-host-names\" href=\"/#/person/{{host.id}}\">{{host.name}}</a></span></h3><span id=\"playing-genres\">{{show.genres}}</span>\n            </div>\n          </div>\n        </div>\n        <div id=\"play-pause-buttons\"><a id=\"play-button\" ng-click=\"playMusic()\" ng-hide=\"playing\" class=\"button button-circle button-primary\"> <span id=\"play-icon\">&#9658;</span></a><a id=\"pause-button\" ng-click=\"pauseMusic()\" ng-show=\"playing\" ng-cloak class=\"button button-circle button-caution\"><span id=\"stop-icon\">I I</span></a></div>\n      </div>\n      <div id=\"chatroom-holder\" ng-controller=\"ChatController\">\n        <section id=\"chatroom\" ng-show=\"showChat\">\n          <header ng-click=\"toggleChat()\">\n            <h1>Chat With Us Live!</h1><img id=\"minimize-icon\" src=\"img/minimize.png\">\n          </header>\n          <iframe width=\"250\" height=\"300\" ng-src=\"{{trustSrc(chatURL)}}\"></iframe>\n        </section>\n        <div id=\"button-holder\">\n          <div id=\"webcam-streamfile-box\"><a id=\"webcam-button\" href=\"/#/webcam\" class=\"button button-rounded button-flat-primary button-tiny\">Watch the Webcam</a><a id=\"streamfile-button\" href=\"http//rock.radio.depaul.edu8000/listen.pls?sid=1\" class=\"button button-rounded button-flat-primary button-tiny\">Download the Streamfile</a></div>\n          <div id=\"chat-player-box\" ng-cloak><a id=\"chat-button\" ng-click=\"toggleChat()\" class=\"button button-rounded button-flat-primary button-tiny\">Chat with our DJs</a><a id=\"player-button\" onClick=\"window.open('../popupplayer.html','toolbar=no, menubar=no, location=no, status=no, titlebar=no','width=390,height=100');\" class=\"button button-rounded button-flat-primary button-tiny\">Pop-up Player</a></div>\n        </div>\n      </div>\n    </div>\n  </header>\n  <script src=\"/js/vendor.js\"></script>\n  <script src=\"/js/app.js\"></script>\n  <script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];if (d.getElementById(id)) return;js = d.createElement(s); js.id = id;js.src = \"//connect.facebook.net/en_US/all.js#xfbml=1&appId=419461828142439\";fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>\n  <script>window.twttr = (function (d,s,id) { var t, js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js=d.createElement(s); js.id=id; js.src=\"https://platform.twitter.com/widgets.js\"; fjs.parentNode.insertBefore(js, fjs); return window.twttr || (t = { _e: [], ready: function(f){ t._e.push(f) } });}(document, \"script\", \"twitter-wjs\"));</script>\n  <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-43005332-1', 'depaul.edu');ga('send', 'pageview');</script>\n</body>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<html>\n  <body>\n    <div id=\"about-nav\">\n      <ul id=\"about-ul\">\n        <li ng-repeat=\"tab in tabs\" ng-class=\"{active: $parent.tabs.active == tab}\" ng-click=\"$parent.tabs.active = tab\">{{tab}}</li>\n      </ul>\n    </div>\n    <section id=\"managers\" ng-show=\"tabs.active==&quot;Managers&quot;\">\n      <header>\n        <h1>Managers</h1>\n      </header>\n      <div ng-repeat=\"manager in managers\" class=\"box about-boxes\"><a href=\"/#/people/{{manager.id}}\" class=\"manager-name\">\n          <p>{{manager.name}}</p></a>\n        <p>{{manager.position}}</p>\n        <p><a href=\"mailto:{{manager.email}}\">{{manager.email}}</a></p>\n        <p>{{manager.phone}} </p><img ng-src=\"{{manager.photo}}\"/>\n      </div>\n    </section>\n    <section id=\"contact\" ng-show=\"tabs.active==&quot;Contact&quot;\">\n      <header>\n        <h1>Contact Info</h1>\n      </header>\n      <div class=\"box about-boxes\">\n        <h2>Station Phone:</h2>\n        <p>(773) 325-7308</p><br/>\n        <h2>Station Fax:</h2>\n        <p>(773) 325-4133</p><br/>\n        <h2>Station Address:</h2>\n        <p>Radio DePaul</p>\n        <p>2250 N. Sheffield Avenue, Suite 317 </p>\n        <p>Chicago, IL 60614</p>\n      </div>\n    </section>\n    <section id=\"mission_statement\" ng-show=\"tabs.active==&quot;Mission Statement&quot;\">\n      <header>\n        <h1>Mission Statement</h1>\n      </header>\n      <div class=\"about-boxes\">\n        <p>Act as an educational and practical training ground for those students who are interested in pursuing radio as a career.</p><br/>\n        <p>Entertain and Inform our audience through innovative and consistent music and non-music programming.</p><br/>\n        <p>Serve the DePaul community by promoting University services, events, and activities.</p><br/>\n        <p>Work cooperatively with other campus groups and organizations to promote and support a varied and exciting collegiate experience for students.</p>\n      </div>\n    </section>\n    <section id=\"join\" ng-show=\"tabs.active==&quot;Join Radio DePaul&quot;\">\n      <header>\n        <h1>Join Radio DePaul</h1>\n      </header>\n      <div class=\"about-boxes\">\n        <div class=\"smallBar eligibility-title\">Eligibility for Participation</div>\n        <p>Only full-time students in good academic standing (2.5 GPA or higher) at DePaul are eligible for FULL membership in Radio DePaul.</p><br/>\n        <p>University faculty members, staff and members of the community also shall be eligible for ASSOCIATE membership through petition to the Student Advisory Committee.</p><br/>\n        <p>Membership constitutes active participation in the organization.</p><br/>\n        <p>Radio DePaul shall not discriminate against any person on the basis of race, color, sex, sexual preference, disabilities, national origin, religious affiliation, or beliefs.</p><br/>\n        <div class=\"smallBar eligibility-title\">Rights and Privileges of Membership</div>\n        <p>The number of persons who may be members of Radio DePaul may be limited depending on the availability of on or off-air positions.</p><br/>\n        <p>Only FULL members of the organization shall be eligible to hold management positions.</p><br/><br/>\n        <center><a id=\"about-apply\" href=\"http://radiodepaul.herokuapp.com/application\">Apply</a></center>\n      </div>\n    </section>\n    <section id=\"sponsor\" ng-show=\"tabs.active==&quot;Sponsor Radio DePaul&quot;\">\n      <header>\n        <h1>Sponsor Radio DePaul</h1>\n      </header>\n      <div class=\"about-boxes\">\n        <p>Sponsoring Radio DePaul is easy and affordable. We have a number of packages that may be right for your organization or business. It is also possible to design your own custom sponsorship package. Please check out our<a href=\"depaul_media_hit.pdf\">media kit</a>and contact us with any questions you have. Keep in mind that in addition to being heard on our site, Radio DePaul is one of handful of college stations that is available on the very popular iHeartRadio app and website. In other words, your organization or businesses name is going to reach a lot of people. Thanks for considering Radio DePaul, Chicago's College Connection!</p><br/>\n        <p><a id=\"media-kit\" href=\"depaul_media_kit.pdf\" class=\"button button-rounded button-flat-primary button-medium\">View/Download Media Kit</a></p><br/>\n        <ul id=\"scott-contact\">\n          <li>\n            <h2>Contact Information\n              <h2></h2>\n            </h2>\n          </li>\n          <li>Scott Vyverman, General Manager</li>\n          <li>Email:<a href=\"mailto:radiodepaulmanagement@gmail.com\">radiodepaulmanagement@gmail.com</a></li>\n          <li>Phone: (773) 325-7399</li>\n          <li>Fax: (773) 325-4133</li>\n        </ul>\n      </div>\n    </section>\n    <section id=\"awards\" ng-show=\"tabs.active==&quot;Awards and Recognition&quot;\">\n      <header>\n        <h1>Awards & Recognition</h1>\n      </header>\n      <div class=\"content\">\n        <ul class=\"segmented\">\n          <li ng-repeat=\"award in awards\">\n            <h2>{{award.name}}</h2>\n            <p>{{award.for}}</p>\n            <p>{{award.year}}</p>\n            <p>{{award.award_organization.name}}</p>\n            <p>{{award.award_organization.url}}</p>\n          </li>\n        </ul>\n      </div>\n    </section>\n  </body>\n</html>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section>\n  <header>\n    <h1><a id=\"home-news-headline\" href=\"/#/station_news\">Radio DePaul News</a></h1>\n  </header>\n  <div class=\"content\">\n    <ul>\n      <li ng-repeat=\"item in news\">\n        <header class=\"headline\">\n          <h2><a href=\"#/station_news/{{item.id}}\">{{item.headline}}</a></h2>\n          <date>{{item.published_at}}</date>\n        </header>\n        <div ng-bind=\"item.snippet\" class=\"content\"></div><a href=\"#/station_news/{{item.id}}\" class=\"read-more-button highlight-color\">Read more ..</a>\n      </li>\n    </ul>\n  </div>\n</section>\n<section id=\"events\">\n  <header>\n    <h1>Coming Up</h1>\n  </header>\n  <div class=\"content\">\n    <ul class=\"segmented\">\n      <li ng-repeat=\"event in events\">\n        <h2>{{event.title}}</h2>\n        <p>{{event.first_line}} - {{event.second_line}}</p>\n        <p>{{event.location}}</p>\n        <p>{{event.description}}</p>\n      </li>\n    </ul>\n  </div>\n</section>\n<section>\n  <header>\n    <h1>Recent Posts</h1>\n  </header>\n  <div disqus=\"page\" class=\"content\"></div>\n</section>\n<div id=\"sponsors\"><br/>\n  <h2>Sponsors of Radio DePaul</h2><a href=\"http://www.costellosandwich.com/\">\n    <div id=\"costello\"></div></a><a href=\"http://www.redmangousa.com/\">\n    <div id=\"redmango\"></div></a><a href=\"#/about/join_radio_depaul\">\n    <div id=\"sponsor-link\"></div></a>\n</div>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<div id=\"lightbox\">\n  <div id=\"image-container-lightbox\" ng-repeat=\"photo in photos\"><img ng-src=\"http://farm{{photo.farm}}.static.flickr.com/{{photo.server}}/{{photo.id}}_{{photo.secret}}_t.jpg\" ng-click=\"setCurrentPhoto(photo)\" class=\"thumbnail-image\"/></div>\n  <div id=\"previous-arrow\"></div><img ng-src=\"http://farm{{currentPhoto.farm}}.static.flickr.com/{{currentPhoto.server}}/{{currentPhoto.id}}_{{currentPhoto.secret}}_m.jpg\"/>\n  <div id=\"next-arrow\"></div>\n</div>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<iframe width=\"700\" height=\"400\" src=\"//www.youtube.com/embed/YbU0H7bIPHg?rel=0\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>\n<!---->\n<!--   <lightbox>-->\n<!--  <section id=\"gallery-thumbnails\">-->\n<!--    <header>-->\n<!--      <h1>Image Galleries</h1>-->\n<!--    </header>-->\n<!--    <flickr>-->\n<!--      <photoset ng-repeat=\"pset in photosets\" id=\"{{pset}}\"></photoset>-->\n<!--      </lightbox> -->\n<!--    </flickr> -->\n<!--  </section>-->\n<section>\n  <header>\n    <h1>Podcasts</h1>\n  </header>\n  <p>Still under construction</p>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section>\n  <header>\n    <h1><a href=\"/#/station_news\">News Posts</a></h1>\n  </header>\n  <div class=\"content\">\n    <ul>\n      <li ng-repeat=\"item in news\">\n        <header class=\"headline\">\n          <h2><a href=\"#/station_news/{{item.id}}\">{{item.headline}}</a></h2>\n          <date>{{item.published_at}}</date>\n        </header>\n        <div ng-bind=\"item.snippet\" class=\"content\"></div><a href=\"#/station_news/{{item.id}}\" class=\"read-more-button highlight-color\">Read more ..</a>\n      </li>\n    </ul>\n  </div>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section>\n  <div class=\"content\">\n    <header class=\"headline\">\n      <h1>{{news.headline}}</h1>\n      <date>{{news.published_at}}</date>\n      <div>{{news.author.name}}</div>\n    </header>\n    <div ng-bind-html=\"news.content\"></div>\n  </div>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<div id=\"person\">\n  <h2 id=\"name\">{{person.name}}</h2>\n  <div class=\"photoBox left\"><img ng-src=\"{{person.photo_medium}}\"/></div>\n  <section ng-show=\"person.shows\" class=\"right host-box\">\n    <header>\n      <h1>Shows Hosted</h1>\n    </header>\n    <ul>\n      <li ng-repeat=\"show in person.shows\" class=\"shows-hosted\"><a href=\"/#/shows/{{show.id}}\"><img ng-src=\"{{show.show_photo_thumb}}\" height=\"50\" width=\"50\"/>\n          <p>{{show.title}}</p></a></li>\n    </ul>\n  </section>\n  <section class=\"right person-info social-box\">\n    <header>\n      <h1>Info</h1>\n    </header>\n    <ul>\n      <li ng-show=\"person.major\">\n        <h2>Major</h2>\n        <p>{{person.major}}</p>\n      </li>\n      <li ng-show=\"person.hometown\">\n        <h2>Hometown</h2>\n        <p>{{person.hometown}}</p>\n      </li>\n      <li ng-show=\"person.class_year\">\n        <h2>Class Year</h2>\n        <p>{{person.class_year}}</p>\n      </li>\n    </ul>\n  </section>\n  <section ng-show=\"person.twitter || person.facebook || person.email || person.linkedin\" class=\"right social-box\">\n    <header>\n      <h1>Follow / E-mail {{person.name}}</h1>\n    </header>\n    <ul id=\"personshowSocial\">\n      <li ng-show=\"person.twitter\" class=\"twitter\"><a href=\"http://twitter.com/{{person.twitter}}\" target=\"_blank\"></a></li>\n      <li ng-show=\"person.facebook\" class=\"facebook\"><a href=\"http://facebook.com/{{person.facebook}}\" target=\"_blank\"></a></li>\n      <li ng-show=\"person.linkedin\" class=\"linkedin\"><a href=\"http://linkedin.com/{{person.linkedin}}\" target=\"_blank\"></a></li>\n      <li ng-show=\"person.email\" class=\"email\"><a href=\"mailto:{{person.email}}\"></a></li>\n    </ul>\n  </section>\n  <section ng-show=\"person.influences\" class=\"clear\">\n    <header>\n      <h1>Influences</h1>\n    </header>\n    <p>{{person.influences}}</p>\n  </section>\n  <section class=\"clear\">\n    <header>\n      <h1>Bio</h1>\n    </header>\n    <p>{{person.bio}}</p>\n  </section>\n  <section id=\"person-tweet\" twitter=\"person.twitter\"></section>\n  <section>\n    <header>\n      <h1>Recent Posts</h1>\n    </header>\n    <div disqus=\"person.name\" class=\"content\"></div>\n  </section>\n</div>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section id=\"schedule\">\n  <header>\n    <h1>Current Schedule</h1>\n    <ul>\n      <li ng-repeat=\"day in days\" ng-class=\"{selected: $parent.selected == day}\" ng-click=\"$parent.selected = day\">{{day|truncate:3:\"\"}}</li>\n    </ul>\n  </header>\n  <div class=\"content\">\n    <h1 class=\"headline\">{{selected}}</h1>\n    <ul id=\"schedule-list\">\n      <li ng-hide=\"filteredShows.length\">\n        <p class=\"show-name\">No shows today</p>\n      </li>\n      <li ng-repeat=\"show in filteredShows = (schedule | filter: {days:selected})\">\n        <h3 class=\"show-name\"><a href=\"/#/shows/{{show.show.id}}\" class=\"highlight-color\">{{show.show.title}}</a><span ng-show=\"show.show.genres\"> | {{show.show.genres}}</span></h3><a href=\"/#show/{{show.show.id}}\"><img ng-src=\"{{show.show.photo_small}}\"/></a>\n        <div id=\"time-holder\">\n          <div class=\"schedule-time\">{{show.start_time}}</div>\n          <div class=\"schedule-time\">{{show.end_time}}</div>\n        </div>\n        <p class=\"show-djs\">with<span ng-repeat=\"host in show.show.hosts\">{{{true: ', ', false: ' '}[!$first && !$last]}}{{{true: 'and ', false: ' '}[$last && !$first]}}<a href=\"/#/people/{{host.id}}\" class=\"highlight-color\">{{host.name}}</a></span></p>\n        <p class=\"show-bio\">{{show.show.short_description}}</p>\n      </li>\n    </ul>\n  </div>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<div id=\"show\">\n  <h1 id=\"name\">{{show.title}}</h1>\n  <div class=\"photoBox left\"><img ng-src=\"{{show.photo_medium}}\"/></div>\n  <div class=\"right half\">\n    <section ng-show=\"show.hosts\">\n      <header>\n        <h1>Hosted By</h1>\n      </header>\n      <div class=\"show-hosts-container\">\n        <ul id=\"host-list\">\n          <li ng-repeat=\"host in show.hosts\">\n            <p><a href=\"/#/people/{{host.id}}\">{{host.name}}<img ng-src=\"{{host.photo_thumb}}\" class=\"show-host-photo\"/></a></p>\n          </li>\n        </ul>\n      </div>\n    </section>\n    <section ng-show=\"show.genres\">\n      <header>\n        <h1>Genres</h1>\n      </header>\n      <div class=\"content\">\n        <p>{{show.genres}}</p>\n      </div>\n    </section>\n    <section ng-show=\"show.scheduled_slots\">\n      <ul class=\"content\">\n        <li>\n          <p>Scheduled At</p>\n        </li>\n        <li ng-repeat=\"slot in show.scheduled_slots\">\n          <p>{{slot.slot}}</p>\n        </li>\n      </ul>\n    </section>\n    <section ng-show=\"show.twitter || show.facebook || show.email\">\n      <header>\n        <h1>Follow {{show.title}}</h1>\n      </header>\n      <ul id=\"personshowSocial\">\n        <li ng-show=\"show.twitter\" class=\"twitter\"><a href=\"http://twitter.com/{{show.twitter}}\" target=\"_blank\"></a></li>\n        <li ng-show=\"show.facebook\" class=\"facebook\"><a href=\"http://facebook.com/{{show.facebook}}\" target=\"_blank\"></a></li>\n        <li ng-show=\"show.email\" class=\"email\"><a href=\"mailto:{{show.email}}\"></a></li>\n      </ul>\n    </section>\n  </div>\n  <section ng-show=\"show.long_description\" class=\"clear\">\n    <header>\n      <h1>Description</h1>\n    </header>\n    <div class=\"content\">\n      <p ng-bind=\"show.long_description | newlines\"></p>\n    </div>\n  </section>\n  <section id=\"person-tweet\" twitter=\"show.twitter\"></section>\n  <section class=\"clear\">\n    <header>\n      <h1>Recent Posts</h1>\n    </header>\n    <div disqus=\"show.title\" class=\"content\"></div>\n  </section>\n</div>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section class=\"shows-section\">\n  <header>\n    <h1>Active Shows</h1>\n    <input ng-model=\"showSearchText\" class=\"search\"/>\n    <image src=\"/img/search.png\" class=\"search-icon\"></image>\n  </header>\n  <ul class=\"segmented dashed\">\n    <li ng-repeat=\"show in filteredItems = (shows | filter:showSearchFilter) | startFrom:currentPage*pageSize | limitTo:pageSize\"><a href=\"/#/shows/{{show.id}}\">\n        <div class=\"small-bar\"><img ng-src=\"{{show.photo_thumb}}\"/><span class=\"show-name\">{{show.title}}</span><span ng-show=\"show.hosts\" class=\"show-hosts\"><span class=\"no-bold\">with</span><span ng-repeat=\"host in show.hosts\">{{{true: ', ', false: ' '}[!$first && !$last]}}{{{true: 'and ', false: ' '}[$last && !$first]}}{{host.name}}</span></span></div></a></li>\n  </ul>\n  <pagination page-size=\"10\" count=\"filteredItems.length\"></pagination>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<section id=\"staff\" class=\"shows-section\">\n  <header>\n    <h1>Radio DePaul Staff</h1>\n    <input ng-model=\"staffSearchText\" ng-change=\"filter()\" class=\"search\"/>\n    <image src=\"/img/search.png\" class=\"search-icon-staff\"></image>\n  </header>\n  <ul>\n    <li ng-repeat=\"person in filteredItems = (staff | filter:staffSearchFilter) | startFrom:currentPage*pageSize |  limitTo:pageSize\" class=\"staff-list\"><a href=\"/#/people/{{person.id}}\" class=\"big\">\n        <div class=\"smallBar\"><img ng-src=\"{{person.photo_thumb}}\" width=\"50\" height=\"50\"/><span class=\"staff-name-list\"><span>{{person.name}}</span><span ng-show=\"person.shows\"> of {{person.shows}}</span></span></div></a></li>\n  </ul>\n  <pagination page-size=\"10\" count=\"filteredItems.length\"></pagination>\n</section>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("\n<h1 style=\"margin-bottom: 10px;\">Live Webcam</h1>\n<div id=\"webcam-player\"></div>\n<h1 style=\"text-align: center;\">Click the play button for audio while watching the webcam</h1>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("<!DOCTYPE html>\n<html>\n  <head>\n    <meta charset=\"utf-8\">\n    <link href=\"http://fonts.googleapis.com/css?family=Cabin\" rel=\"stylesheet\" type=\"text/css\">\n    <style>body{background-image:url(../img/cream_pixels.png);font-family:'Cabin',sans-serif}div.jp-audio,div.jp-video{font-size:1.25em}#player-container{position:relative;bottom:20px}#popupcantainer{position:relative;bottom:15px}</style>\n  </head>\n  <body>\n    <div id=\"popupcantainer\">\n      <h3>Radio DePaul Stream</h3>\n      <div id=\"player-container\">\n        <script src=\"http://player.wavepanel.net/embed/basic/64c829446c484becd92959d9b08a8fab7c2f9c67\"></script>\n      </div>\n    </div>\n  </body>\n</html>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;var __templateData = function anonymous(locals) {
var buf = [];
jade.indent = [];
buf.push("<!DOCTYPE html>\n<html>\n  <head>\n    <meta charset=\"utf-8\">\n    <title>Radio DePaul Sports</title>\n    <meta name=\"description\" content=\"\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"/css/sports.css\">\n    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"../favicon.ico\">\n    <script type=\"text/javascript\" src=\"/js/webflow.js\" defer=\"defer\"></script>\n  </head>\n  <body>\n    <div class=\"section header\">\n      <div class=\"w-container\">\n        <div class=\"w-row\">\n          <div class=\"w-col w-col-2 company-column\"><img id=\"logo\" src=\"../img/logo.png\"><img id=\"sports-logo\" src=\"../img/athletics-logo.svg\"></div>\n          <div class=\"w-col w-col-10 nav-bar\"><a href=\"#\" class=\"nav-link\">Blue Demon Weekly</a><a href=\"#\" class=\"nav-link\">Blue Demon Play by Play</a><a href=\"#podcasts\" class=\"nav-link\">Podcasts</a><a href=\"http://www.depaulbluedemons.com/\" class=\"nav-link\">DePaul Athletics Home</a><a href=\"http://www.depaulbluedemons.com/\" class=\"nav-link\">Radio DePaul</a></div>\n        </div>\n      </div>\n    </div>\n    <div>\n      <div class=\"hero-bg\">\n        <div class=\"w-container\">\n          <h1 id=\"page-nav-Section-1\">This is what we play for!</h1>\n          <div class=\"subtitle\">Men's basketball game at the Allstate Arena</div>\n        </div>\n      </div>\n    </div>\n    <div class=\"section\">\n      <div class=\"w-container\">\n        <div style=\"position: relative; bottom: 80px;\" class=\"w-row\">\n          <div class=\"w-col w-col-6\">\n            <h3>DePaul Athletics Feed</h3>\n            <div class=\"section-description\">Keep up with the latest in DePaul Athletics.</div>\n          </div>\n          <div class=\"w-col w-col-6 right-col\"><a href=\"http://www.depaulbluedemons.com/s-finder/depa-s-finder.html\" target=\"_self\" class=\"more-link\">More DePaul Sports Info</a></div>\n        </div>\n        <div class=\"w-row snippet-row\">\n          <div class=\"w-col w-col-3 w-col-small-6\"><a href=\"http://www.depaulbluedemons.com/sports/c-track/spec-rel/081513aaa.html\" class=\"w-inline-block snippet\">\n              <div id=\"snippet1\" class=\"snippet-img\"></div>\n              <div class=\"snippet-text-section\">\n                <div class=\"snippet-title\">Track</div>\n                <div class=\"snippet-text\">DePaul Track and Field Primed to Seize the Moment in New BIG EAST</div>\n              </div></a></div>\n          <div class=\"w-col w-col-3 w-col-small-6\"><a href=\"http://www.depaulbluedemons.com/sports/c-xc/spec-rel/081513aaa.html\" class=\"w-inline-block snippet\">\n              <div id=\"snippet2\" class=\"snippet-img\"></div>\n              <div class=\"snippet-text-section\">\n                <div class=\"snippet-title\">Cross Country</div>\n                <div class=\"snippet-text\">DePaul Track and Field Primed to Seize the Moment in New BIG EAST</div>\n              </div></a></div>\n          <div class=\"w-col w-col-3 w-col-small-6\"><a href=\"http://www.depaulbluedemons.com/sports/w-soccer/spec-rel/081513aac.html\" class=\"w-inline-block snippet\">\n              <div id=\"snippet3\" class=\"snippet-img\"></div>\n              <div class=\"snippet-text-section\">\n                <div class=\"snippet-title\">Women's Soccer</div>\n                <div class=\"snippet-text\">DePaul Comes Out Shooting in 3-2 Exhibition Loss to Northwestern</div>\n              </div></a></div>\n          <div class=\"w-col w-col-3 w-col-small-6\"><a href=\"http://www.depaulbluedemons.com/sports/m-soccer/spec-rel/081313aac.html\" class=\"w-inline-block snippet\">\n              <div id=\"snippet4\" class=\"snippet-img\"></div>\n              <div class=\"snippet-text-section\">\n                <div class=\"snippet-title\">Men's Soccer</div>\n                <div class=\"snippet-text\">BIG EAST Conference Announces Preseason Coaches' Poll</div>\n              </div></a></div>\n        </div>\n      </div>\n    </div>\n    <div class=\"content-bg\">\n      <div class=\"w-container\">\n        <h2 id=\"page-nav-Section-2\">We are calling the shots. Every game. Every week.</h2>\n      </div>\n    </div>\n    <div class=\"section\">\n      <div class=\"w-container\">\n        <div class=\"w-row\">\n          <div class=\"w-col w-col-6\">\n            <h3>Opportunities at Radio DePaul</h3>\n            <p>Whether your sitting inside the pressbox at Cacciatore Stadium broadcasting Soccer, on the court announcing a men's basketball game at the Allstate Arena, or interviewing our DePaul's President Dr. Dennis Holtschneider, Radio DePaul is here to open doors for you. Offering students the opportunities of their dreams.</p><br>\n            <p>You always hear that college is what you make it. So why not make it fun?  Why not leave your mark? Being apart of the Radio DePaul family is more than just getting to broadcast your show, it's about making connections and creating opportunities that you may never have gotten a chance to before.</p>\n          </div>\n          <div class=\"w-col w-col-6\">\n            <div class=\"w-row\">\n              <div class=\"w-col w-col-6 two-image-holder\"><img src=\"../img/c-stadium.png\" width=\"130\" alt=\"Cacciatore Stadium\" class=\"img-example\"><img src=\"../img/pres-interview.png\" width=\"130\" alt=\"President Dennis Holtschneider Interview\" class=\"img-example\"></div>\n              <div class=\"w-col w-col-6 two-image-holder\"><img src=\"../img/w-bball-coach.png\" width=\"130\" alt=\"Women&quot;s Basketball Coach Interview\" class=\"img-example\"><img src=\"../img/broadcast.png\" width=\"130\" alt=\"image-placeholder.svg\" class=\"img-example\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"content-bg two\">\n      <div class=\"w-container\">\n        <h2 id=\"page-nav-Section-3\">And no one is getting in our way.</h2>\n      </div>\n    </div>\n    <div id=\"podcasts\" class=\"section\">\n      <div class=\"w-container\">\n        <div class=\"w-row\">\n          <div class=\"w-col w-col-12\">\n            <h3>Podcasts</h3>\n          </div>\n        </div>\n      </div>\n      <div class=\"section footer\">\n        <div class=\"w-container\">\n          <div class=\"w-row secondary-row\">\n            <div class=\"w-col w-col-8 w-col-small-6\">\n              <h3>Join the Radio DePaul Sports Team</h3>\n              <p>Want to get in on the action?  Want to cover DePaul athletic games and events?  Well here is your chance!  Apply to Radio DePaul and specify your interest in sports broadcasting and you may just find yourself at front row and broadcasting the game live over Radio DePaul!</p>\n            </div>\n            <div class=\"w-col w-col-4 w-col-small-6 button-column\"><a href=\"http://radiodepaul.herokuapp.com/application\" class=\"button\">Apply Now!</a></div>\n          </div>\n        </div>\n      </div>\n      <div class=\"section\">\n        <div class=\"w-container\">\n          <div class=\"w-row\">\n            <div class=\"w-col w-col-6 left-footer-col\">\n              <div class=\"footer-text\">© Radio DePaul Sports. All Rights Reserved.</div>\n            </div>\n            <div class=\"w-col w-col-6 footer-nav-bar\"><a href=\"#\" class=\"footer-link\">Radio DePaul</a><a href=\"#\" class=\"footer-link\">Blue Demon Weekly</a><a href=\"http://www.depaulbluedemons.com/\" class=\"footer-link\">DePaul Athletics</a></div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </body>\n</html>");;return buf.join("");
};
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
;
//@ sourceMappingURL=templates.js.map